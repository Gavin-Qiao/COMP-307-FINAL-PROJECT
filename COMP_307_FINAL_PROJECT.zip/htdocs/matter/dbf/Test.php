<?php

/* Database test
$pdo = new PDO('sqlite:TA_Management_Website.db');

$statement = $pdo -> query("SELECT * FROM USER;");

$rows = $statement -> fetchAll(PDO::FETCH_ASSOC);

var_dump($rows);
*/

// Autoloader
spl_autoload_register(function ($class_name)
{
    require $class_name.'.php';
});

/* CSV downloadable test
$fileContent  = "Id,First name,Last name\n";
$fileContent .= "1,Jack,Doe\n";
$fileContent .= "2,Jill,Jackson\n";

header("Content-type: application/csv");
header("Content-Disposition: attachment; filename=output.csv");
header("Pragma: no-cache");
header("Expires: 0");

echo $fileContent;
*/

$stm_lib = new SQL_STATEMENTS();

$login  = new UserManagement($stm_lib::DATABASE_NAME);
$course = new CourseManagement($stm_lib::DATABASE_NAME);

print_r($login->Get_TA_Info("260927120"));

